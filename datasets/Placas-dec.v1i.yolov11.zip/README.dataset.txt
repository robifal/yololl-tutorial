# Placas-dec > 2024-12-20 3:00pm
https://universe.roboflow.com/teste-de-placas/placas-dec

Provided by a Roboflow user
License: CC BY 4.0

